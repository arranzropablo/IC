function norma = norma(x, v)

  norma = sqrt(sum((x-v).^2));

endfunction
